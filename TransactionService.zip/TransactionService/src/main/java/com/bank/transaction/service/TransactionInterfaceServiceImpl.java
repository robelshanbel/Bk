package com.bank.transaction.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bank.transaction.dto.CustInformationResponse;
import com.bank.transaction.dto.TransactionHistory;
import com.bank.transaction.dto.TransactionResponse;
import com.bank.transaction.dto.testBankResponse;
import com.bank.transaction.model.BankTransaction;
import com.bank.transaction.repository.TransactionRepository;

@Service
public class TransactionInterfaceServiceImpl implements TransactionInterfaceService {
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	TransactionRepository transactionRepository;
	
	
	
	
	
	
//Method-One ===================================================================================================
	@Override
	public TransactionResponse transaction(BankTransaction bankTransaction) {
		// TODO Auto-generated method stub
		 if (bankTransaction.getTransactionType().equals("withdrawal")) {
				
				// call bankingApp api using -> restTemplate or( webclient, fignclient)  
				  String url1="http://localhost:9094/api/v1/fetch/";
				  
				  
				 CustInformationResponse custIformationResponse =  restTemplate.getForObject(url1 + bankTransaction.getUserId() , CustInformationResponse.class);
				 
				 
				
				 if (custIformationResponse.getBalance()> bankTransaction.getAmount()) {
					
					
					 
					 
					 double newBalance=custIformationResponse.getBalance()-bankTransaction.getAmount();
					 
					 String url2="http://localhost:9094/api/v1/modUpdate/{id}/{amount}";
					 restTemplate.put(url2, null,bankTransaction.getUserId(), newBalance );
					 
					 transactionRepository.save(bankTransaction);
					 
					 TransactionResponse response= new TransactionResponse(bankTransaction,"200", "withdrawal done");
					 
					
					 
							  
					return response;
					 
				}
				 
				 else {
					 
					return null;
				 }
				 
				  
			    }
				
			  else if(bankTransaction.getTransactionType().equals("deposit")) {
				  
				

				  String url2="http://localhost:9094/api/v1/fetch/";
				  
				  CustInformationResponse custInformationResponse=  restTemplate.getForObject(url2+bankTransaction.getUserId(), CustInformationResponse.class);
				 
				 double newBalance=custInformationResponse.getBalance()+bankTransaction.getAmount();
				  
				 
				 
				 
				 String url3="http://localhost:9094/api/v1/modUpdate/{id}/{amount}";
				 
				 restTemplate.put(url3,null, bankTransaction.getUserId(), newBalance );
				
				   TransactionResponse response= new TransactionResponse(bankTransaction, "200", "deposit done");
				   
				   transactionRepository.save(bankTransaction);
				   
				   return response;
				  
				  
				  
			  }
				
			  else {
				  
				  return null;
			  }
				
				
	}

	
	
	
//Method-Two ===================================================================================================	
	


@Override
public TransactionHistory transactionHistory(String userid) {
	// TODO Auto-generated method stub
	
	TransactionHistory transactionHistory = new TransactionHistory();
	
	

	CustInformationResponse custInformationResponse=  restTemplate.getForObject("http://localhost:9094/api/v1/fetch/" + userid, CustInformationResponse.class);
	
    List<BankTransaction> bankTransactions= transactionRepository.findByUserId(userid);
    
    
	transactionHistory.setBankTransactions(bankTransactions);
	transactionHistory.setCustInformationResponse(custInformationResponse);
	
	
	
	
	//TransactionHistory history= new TransactionHistory(custInformationResponseHistory, bankTransactions);
    
	
	//return history;
	return transactionHistory;
	
}




//@Override
//public testBankResponse bankResponse() {
//	// TODO Auto-generated method stub
//	CustInformationResponse custInformationResponse=  restTemplate.getForObject("http://localhost:9094/api/v1/fetchAll", CustInformationResponse.class);
//	
//	testBankResponse bankResponse =new testBankResponse();
//	bankResponse.setCustInformationResponses(custInformationResponse);
//	
//	return bankResponse ;
//}


//End Of ALL Methods ================================================================================================

}



