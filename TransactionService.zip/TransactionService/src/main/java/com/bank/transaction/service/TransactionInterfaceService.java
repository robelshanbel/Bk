package com.bank.transaction.service;




import com.bank.transaction.dto.TransactionHistory;
import com.bank.transaction.dto.TransactionResponse;
import com.bank.transaction.dto.testBankResponse;
import com.bank.transaction.model.BankTransaction;



public interface TransactionInterfaceService {
	
	public TransactionResponse transaction(BankTransaction bankTransaction );
	
	public TransactionHistory transactionHistory(String userid);
	
	
	//public testBankResponse bankResponse();

}




