package com.bank.transaction.dto;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@Setter
@Getter
public class testBankResponse {

	
	
CustInformationResponse custInformationResponses;
}
