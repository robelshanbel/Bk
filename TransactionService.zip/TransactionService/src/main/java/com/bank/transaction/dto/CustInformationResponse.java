package com.bank.transaction.dto;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import lombok.AllArgsConstructor;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class CustInformationResponse {
	
	
	private int custId;
	private String fullName;
	private String accountType;
	private String status;
	private double balance;
	private additional_info additionalinfo;

}




