package com.bank.transaction.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bank.transaction.model.BankTransaction;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor



public class TransactionHistory {
	
	
	private CustInformationResponse custInformationResponse;
	
	private List<BankTransaction> bankTransactions;
	
	

	

	
	

	
/*	
	public CustInformationResponse getCustInformationResponse() {
		
		return custInformationResponse;	
		
		}
	
	public void setCustInformationResponse(CustInformationResponse custInformationResponse) {
		
		this.custInformationResponse = custInformationResponse;
	}
	
	public List<BankTransaction> getBankTransactions() {
		
		return bankTransactions;
	}
	
	public void setBankTransactions(List<BankTransaction> bankTransactions) {
		
		this.bankTransactions = bankTransactions;
	}*/
	
	

}
