package com.bank.transaction.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity

public class BankTransaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private int transactionId;
	private String transactionType;
	private String transactionDesc;
	private double amount;
	private String userId;
	

}
