package com.bank.transaction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.transaction.dto.TransactionHistory;
import com.bank.transaction.model.BankTransaction;
import com.bank.transaction.service.TransactionInterfaceService;
import org.springframework.web.bind.annotation.RequestParam;


@RestController

@RequestMapping("/api/v1/banktransactionMap")

public class TransactionController {
	
	@Autowired
	TransactionInterfaceService  transactionService;
	
	@PostMapping("/createTransaction")
	
	public ResponseEntity<?>transaction(@RequestBody BankTransaction transaction){
		
		
		
		return new ResponseEntity<>(transactionService.transaction(transaction),HttpStatus.OK);
		
	}

	@GetMapping("/getBankTransaction/{id}")
	
	//@CircuitBreaker(name = "bankingappCircuitBreaker"  , fallbackMethod = "bankingappfallbackMethod"  )
	
	public ResponseEntity<?> transactionhistory(@PathVariable("id") String userid){
		
		
		//TransactionHistory historyData=transactionService.transactionHistory(userid);
		return new ResponseEntity<>(transactionService.transactionHistory(userid),HttpStatus.OK);
		
	}
	
	//public ResponseEntity<?> bankingappfallbackMethod(int id,Exception exception ){
		
		
		
		//return new ResponseEntity<>("bankingapp is down please try leater ", HttpStatus.INTERNAL_SERVER_ERROR);
	//}
	
	
	@DeleteMapping("/delete")
	public String delete() {
		
		return " delete";
	}
	
	
	@GetMapping("/getallbankdata")
	public ResponseEntity<?> getMethodName() {
		return new ResponseEntity<>(transactionService.bankResponse(),HttpStatus.ACCEPTED);
	}
	
	

}
