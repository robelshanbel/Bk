package com.bankofUSA.departmentName.banking.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankofUSA.departmentName.banking.model.custInformation;
import com.bankofUSA.departmentName.banking.repository.CustomerInformationRepository;

@Service
public class custInformationImplementation implements CustomerInformationService{
	
	@Autowired
	CustomerInformationRepository custRepository;
	
	//custInformationImplementation obj= new custInformationImplementation();
	
	@Override
	public custInformation createCust(custInformation custInformation) {
		// TODO Auto-generated method stub
		
		custRepository.save(custInformation);//custInformation custInfo=
		return custInformation;
	}

	@Override
	public custInformation getOneCustomerInfo(int id) {
		// TODO Auto-generated method stub
		Optional<custInformation> optional = custRepository.findById(id);
		if(optional.isPresent())
			return optional.get();
		else
		return null;
	}

	@Override
	public List<custInformation> getAllCustInformation() {
		// TODO Auto-generated method stub
		return custRepository.findAll();
	}

	@Override
	public custInformation deleteInfo(int id) {
		// TODO Auto-generated method stub
		//List<custInformation> list= new ArrayList<custInformation>();
		//list=custRepository.findAll();
		
		if(getOneCustomerInfo(id)!=null) {
			
		
		custInformation custData= getOneCustomerInfo(id);
		custRepository.deleteById(id);
		return custData;
		}
		else
		return  null; 
		
		
	}

	@Override
	public String updatecustAmount(int id, Double amount) {
		// TODO Auto-generated method stub
		if(getOneCustomerInfo(id)!=null) {
			
			
			custInformation custData= getOneCustomerInfo(id);
			custData.setBalance(amount);
			custRepository.save(custData);
			return "Updated Successfully !!!";
			
			}
			else
			return  null; 
	}

	

}



