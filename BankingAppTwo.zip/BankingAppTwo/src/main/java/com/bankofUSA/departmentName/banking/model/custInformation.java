package com.bankofUSA.departmentName.banking.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Setter
@Getter


@AllArgsConstructor
@NoArgsConstructor
public class custInformation {
	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int custId;
	private String fullName;
	private String accountType;
	private String status;
	private double balance;
	private Additional_Information additional_information;
	

}
