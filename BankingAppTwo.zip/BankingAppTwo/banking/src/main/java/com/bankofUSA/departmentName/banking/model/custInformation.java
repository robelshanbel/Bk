package com.bankofUSA.departmentName.banking.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity





public class custInformation {
	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int custId;
	private String fullName;
	private String accountType;
	private String status;
	private double balance;
	private Additional_Information additional_information;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Additional_Information getAdditional_information() {
		return additional_information;
	}
	public void setAdditional_information(Additional_Information additional_information) {
		this.additional_information = additional_information;
	}
	
	
	

}
