package com.bankofUSA.departmentName.banking.service;

import java.util.List;

import com.bankofUSA.departmentName.banking.model.custInformation;

public interface CustomerInformationService {
	
	public custInformation createCust(custInformation custInformation);
	public custInformation getOneCustomerInfo(int id);
	public List<custInformation> getAllCustInformation();
	public custInformation deleteInfo(int id);

}
