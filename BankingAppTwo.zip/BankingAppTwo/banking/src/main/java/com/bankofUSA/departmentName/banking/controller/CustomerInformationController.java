package com.bankofUSA.departmentName.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import com.bankofUSA.departmentName.banking.model.custInformation;
import com.bankofUSA.departmentName.banking.service.CustomerInformationService;

@RestController
@RequestMapping("/api/v1")
public class CustomerInformationController {
	
	@Autowired
	CustomerInformationService custService;
	
	Map<String, Object> custdata =new HashMap<String, Object>();
	
	
	
	@PostMapping("/create")
	ResponseEntity<?> createCustInformation(@RequestBody custInformation custInfo){
		//custInformation customerData =custService.createCust(custInfo);
		//custdata.put("data",customerData);
		
		return new ResponseEntity<>(custService.createCust(custInfo),HttpStatus.CREATED);
		
		
	
	}
	
	//===================================================
	
	@GetMapping("/fetch/{id}")
	ResponseEntity<?> fetchCustInfo(@PathVariable int id){
		custInformation custInfoDetail = custService.getOneCustomerInfo(id);
		return new ResponseEntity<>(custInfoDetail,HttpStatus.OK);
	}
	
	//===================================================
	@GetMapping("/fetchAll")
	
	public List<custInformation> fetchAllCustInformation(){
		return custService.getAllCustInformation();
	}
   @DeleteMapping("/delete/{id}")
   public custInformation deleteCustInformation(@PathVariable int id) {
	   return custService.deleteInfo(id);
   }
}
