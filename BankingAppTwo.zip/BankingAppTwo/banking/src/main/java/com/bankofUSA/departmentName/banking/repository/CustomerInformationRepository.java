package com.bankofUSA.departmentName.banking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bankofUSA.departmentName.banking.model.custInformation;

@Repository
public interface CustomerInformationRepository extends JpaRepository<custInformation,Integer>{

}
